# Perpustakaan Digital MTs Al Uswah

Website multi-page: Beranda, Katalog, Login Petugas, Dashboard Admin, Dashboard Petugas.

## Setup Supabase
1. Buat project di https://supabase.com/dashboard.
2. Jalankan seluruh SQL di `supabase/migrations/001_initial_schema.sql` melalui SQL Editor.
3. Buka Project Settings > API, salin Project URL dan anon/public key ke `assets/js/config.js`.
4. Buat akun admin pertama melalui Authentication > Users > Add user.
5. Salin UUID akun admin tersebut, lalu jalankan SQL: `update public.profiles set role='admin' where id='UUID_AKUN_ADMIN';`

## Deploy fungsi pembuatan akun petugas
Install Supabase CLI, lalu dari folder project jalankan:
```bash
supabase link --project-ref PROJECT_REF
supabase functions deploy create-staff
supabase secrets set SUPABASE_URL=https://PROJECT_REF.supabase.co SUPABASE_ANON_KEY=ANON_KEY SUPABASE_SERVICE_ROLE_KEY=SERVICE_ROLE_KEY
```
Service role key hanya boleh disimpan sebagai secret server-side. Jangan taruh di HTML/JavaScript dan jangan commit ke GitHub.

## Deploy website
Upload seluruh isi folder ini ke repository GitHub, lalu import repository ke Vercel. Website statis, jadi tidak memerlukan build command khusus.

Catatan: katalog publik bisa dibaca siapa pun. Perubahan data buku memerlukan akun petugas/admin dan dilindungi Row Level Security. Fitur peminjaman/pengembalian belum termasuk. Minta izin sekolah sebelum menggunakan data dan identitas resmi sekolah.
